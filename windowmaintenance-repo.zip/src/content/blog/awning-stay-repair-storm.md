---
title: Awning Stay Replacement After Wellington Storm
description: Bent awning stays replaced, sash re-aligned and seals tested — no more draughts or leaks.
pubDate: 2025-11-06
---

Last week’s storm bent the awning stays on a customer’s sash window. We replaced the damaged stays, re‑aligned the sash and tested the seals — no more draughts or leaks.

They told us we were the only ones who replied, and left a glowing review after the job. If your window won’t open/close properly or whistles in the wind, we can help.

- Awning stays & restrictors replaced
- Hinges, handles & locks serviced
- Draught and leak diagnosis
- Sliding/ranchslider door repairs

Serving the Wellington region with fast quotes and tidy workmanship.

![New awning stay with old damaged stay visible](\/img\/window-stay-replacement.jpg)

