export default { content: ["./src/**/*.{astro,html,js,jsx,ts,tsx,vue,svelte,md,mdx}"],
  theme: { extend: { colors: { slate: { 950: "#0f172a" } }, borderRadius: { "2xl": "1rem" } } }, plugins: [] };
